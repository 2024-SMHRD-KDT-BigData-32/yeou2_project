import "../css/Login2.css";
import React from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {



    
    const navigate = useNavigate(); 
    
    const signUpBtnClick = () => {
        navigate('/SignUp'); // 이동할 경로
    };
    const findIdBtnClick = () => {
        navigate('/FindID'); // 이동할 경로
    };
    const findPwBtnClick = () => {
        navigate('/FindPW'); // 이동할 경로
    };
    



    return (
        <div id='login'>

            <div className="loginLabel">로그인</div>
            <div className="idLabel">ID</div>
            <input className="idInput" placeholder="아이디를 입력해주세요" type="text" />

            <div className="pwLabel">PW</div>
            <input className="pwInput" placeholder="비밀번호를 입력해주세요" type="text" />


            
            <input className="userDio" type="radio"  name="terms"></input>
            <div className="userLabel ">사용자</div>

            <input className="adminDio" type="radio"  name="terms"></input>
            <div className="adminLabel">관리자</div>


            <button className="loginBtn">로그인</button>
            <button className="googleBtn">Google로그인</button>
            
            <button className="kakaoBtn">KaKAO로그인</button>
            

            <button className="div7" onClick={ findIdBtnClick }>아이디찾기</button>
            <button className="div9" onClick={ findPwBtnClick }>비밀번호찾기</button>
            <button className="div11" onClick={ signUpBtnClick }>회원가입</button>

            


        </div>
    )
}

export default Login