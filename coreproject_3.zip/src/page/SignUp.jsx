import { useNavigate } from "react-router-dom";
import "../css/SignUp.css";
import React from 'react';

const SignUp = () => {

    const navigate = useNavigate(); 
    
    const signUpBtnClick = () => {
        navigate('/SignUp'); // 이동할 경로
    };
    const findIdBtnClick = () => {
        navigate('/FindID'); // 이동할 경로
    };
    const findPwBtnClick = () => {
        navigate('/FindPW'); // 이동할 경로
    };
    const loginBtnClick = () => {
        navigate('/login'); // 이동할 경로
    };





    return (
        <div id='signUp'>
            {/* 제목 */}
            <div className="mainLabel">회원가입</div>

            {/* 아이디 */}
            <div className="idLabel">ID</div>
            <input className="idInput"></input>
            <button className="idBtn">중복확인</button>

            {/* 비밀번호 */}
            <div className="pwLabel">PW</div>
            <input className="pwInput"></input>

            {/* 비번 확인 */}
            <div className="pwLabel2">PW 확인</div>
            <input className="pwInput2"></input>

            {/* 이름 */}
            <div className="nameLabel">이름</div>
            <input className="nameInput"></input>

            {/* 닉네임 */}
            <div className="nickLabel">닉네임</div>
            <input className="nickInput"></input>

            {/* 성별 */}
            <div className="genderLabel">성별</div>

            <div className="maleLabel">남자</div>
            <input type="radio" className="maleRio" name='gender'></input>

            <div className="femaleLabel">여자</div>
            <input type="radio" className="femaleRio" name='gender'></input>

            {/* 생년월일 */}
            <div className="birthLabel">생년월일</div>

            <div className="birthDropbox">
                {/* year 드롭박스 */}
                <select className='yearInput' name="year" id="">
                    <option value="01">1990</option>
                    <option value="02">1992</option>
                    <option value="03">1999</option>
                    <option value="04">2002</option>
                </select>

                {/* month 드롭박스 */}
                <select className='monthInput' name="month" id="">
                    <option value="01">1월</option>
                    <option value="02">2월</option>
                    <option value="03">3월</option>
                    <option value="04">4월</option>
                    <option value="08">5월</option>
                    <option value="06">6월</option>
                    <option value="07">7월</option>
                    <option value="08">8월</option>
                    <option value="09">9월</option>
                    <option value="10">10월</option>
                    <option value="11">11월</option>
                    <option value="12">12월</option>
                </select>
                {/* day 드롭박스 */}
                <select className='dayInput' name="day" id="">
                    <option value="12">12일</option>
                </select>
            </div>


            <div className="emailLabel">이메일</div>
            <input type="email" className="emailInput"></input>

            <button className="signUpBtn" onClick={loginBtnClick} >회원가입 완료</button>
            <button className="backBtn" onClick={loginBtnClick}>로그인</button>
            




        </div>
    )
}

export default SignUp